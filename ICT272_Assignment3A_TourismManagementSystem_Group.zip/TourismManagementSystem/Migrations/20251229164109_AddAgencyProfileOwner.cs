﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TourismManagementSystem.Migrations
{
    /// <inheritdoc />
    public partial class AddAgencyProfileOwner : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AgencyProfiles_AspNetUsers_UserId",
                table: "AgencyProfiles");

            migrationBuilder.DropIndex(
                name: "IX_AgencyProfiles_UserId",
                table: "AgencyProfiles");

            migrationBuilder.DropColumn(
                name: "LogoPath",
                table: "AgencyProfiles");

            migrationBuilder.DropColumn(
                name: "TourGuideName",
                table: "AgencyProfiles");

            migrationBuilder.RenameColumn(
                name: "UserId",
                table: "AgencyProfiles",
                newName: "AgencyUserId");

            migrationBuilder.RenameColumn(
                name: "AgencyProfileId",
                table: "AgencyProfiles",
                newName: "Id");

            migrationBuilder.AddColumn<int>(
                name: "AgencyProfileId",
                table: "AspNetUsers",
                type: "INTEGER",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "ServicesOffered",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 2000,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "TEXT",
                oldMaxLength: 200,
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 2000,
                nullable: false,
                defaultValue: "",
                oldClrType: typeof(string),
                oldType: "TEXT",
                oldMaxLength: 500,
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Address",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 300,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ContactEmail",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 120,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ContactPhone",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 30,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "ImageUrl",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 500,
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<string>(
                name: "TourGuideInfo",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 2000,
                nullable: false,
                defaultValue: "");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_AgencyProfileId",
                table: "AspNetUsers",
                column: "AgencyProfileId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_AgencyProfiles_AgencyProfileId",
                table: "AspNetUsers",
                column: "AgencyProfileId",
                principalTable: "AgencyProfiles",
                principalColumn: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_AgencyProfiles_AgencyProfileId",
                table: "AspNetUsers");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_AgencyProfileId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "AgencyProfileId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "Address",
                table: "AgencyProfiles");

            migrationBuilder.DropColumn(
                name: "ContactEmail",
                table: "AgencyProfiles");

            migrationBuilder.DropColumn(
                name: "ContactPhone",
                table: "AgencyProfiles");

            migrationBuilder.DropColumn(
                name: "ImageUrl",
                table: "AgencyProfiles");

            migrationBuilder.DropColumn(
                name: "TourGuideInfo",
                table: "AgencyProfiles");

            migrationBuilder.RenameColumn(
                name: "AgencyUserId",
                table: "AgencyProfiles",
                newName: "UserId");

            migrationBuilder.RenameColumn(
                name: "Id",
                table: "AgencyProfiles",
                newName: "AgencyProfileId");

            migrationBuilder.AlterColumn<string>(
                name: "ServicesOffered",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 200,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "TEXT",
                oldMaxLength: 2000);

            migrationBuilder.AlterColumn<string>(
                name: "Description",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 500,
                nullable: true,
                oldClrType: typeof(string),
                oldType: "TEXT",
                oldMaxLength: 2000);

            migrationBuilder.AddColumn<string>(
                name: "LogoPath",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 200,
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "TourGuideName",
                table: "AgencyProfiles",
                type: "TEXT",
                maxLength: 120,
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_AgencyProfiles_UserId",
                table: "AgencyProfiles",
                column: "UserId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_AgencyProfiles_AspNetUsers_UserId",
                table: "AgencyProfiles",
                column: "UserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
